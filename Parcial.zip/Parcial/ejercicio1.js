const readline = require('readline');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

rl.question("Ingrese su nombre completo: ", (nombre) => {
    let limpio = nombre.replace(/\s/g, ""); // quitar espacios
    let primeros5 = limpio.substring(0, 5).toLowerCase();
    let correo = primeros5 + "@gmail.com";

    console.log(`Nombre ingresado: ${nombre}`);
    console.log(`Correo generado: ${correo}`);

    rl.close();
});
