const readline = require('readline');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

rl.question("Ingrese una frase: ", (frase) => {
    let primeros6 = frase.substring(0, 6);

    console.log(`Frase ingresada: ${frase}`);
    console.log(`Primeros 6 caracteres: ${primeros6}`);

    rl.close();
});
