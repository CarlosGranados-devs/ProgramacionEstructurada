const readline = require('readline');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

rl.question("Ingrese un texto: ", (texto) => {
    let reemplazado = texto
        .replace(/a/gi, "@")
        .replace(/e/gi, "#")
        .replace(/i/gi, "$")
        .replace(/o/gi, "%")
        .replace(/u/gi, "&");

    console.log(`Texto original: ${texto}`);
    console.log(`Texto con reemplazos: ${reemplazado}`);

    rl.close();
});
