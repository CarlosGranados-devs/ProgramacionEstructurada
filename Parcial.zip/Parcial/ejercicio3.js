const readline = require('readline');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

rl.question("Ingrese una frase que contenga la palabra 'usuario': ", (frase) => {
    let posicion = frase.toLowerCase().indexOf("usuario");

    if (posicion !== -1) {
        console.log(`La palabra 'usuario' aparece en la posición: ${posicion}`);
    } else {
        console.log("La palabra 'usuario' no fue encontrada.");
    }

    rl.close();
});

